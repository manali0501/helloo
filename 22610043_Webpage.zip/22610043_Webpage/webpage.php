<?php
// PHP section: handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $message = $_POST["message"];
    
    // Simple server-side validation (can be expanded)
    if (!empty($username) && !empty($message)) {
        echo "<p>Form submitted successfully. Welcome, $username!</p>";
        // You can add database interactions here if needed
    } else {
        echo "<p style='color:red;'>Please fill in all fields.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Combined JS and PHP Webpage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f7f7f7;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        // JavaScript section: form validation
        function validateForm() {
            var username = document.forms["userForm"]["username"].value;
            var message = document.forms["userForm"]["message"].value;

            if (username == "" || message == "") {
                alert("All fields must be filled out!");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Combined JavaScript & PHP Form</h2>

        <!-- Form submission handled by PHP -->
        <form name="userForm" method="post" onsubmit="return validateForm()">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username">

            <label for="message">Your Message:</label>
            <textarea id="message" name="message"></textarea>

            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
