<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $queryType = $_POST['myQuery'];
    $name = $_POST['myName'];
    $email = $_POST['myEmail'];
    $phone = $_POST['myPhone'];
    $member = isset($_POST['eligible']) ? $_POST['eligible'] : 'No';
    $message = $_POST['mesg'];

    // Validate input (simple example)
    if (empty($name) || empty($email) || empty($message)) {
        echo "Please fill in all the required fields.";
    } else {
        // Save or send form data (e.g., store in database or send an email)
        // For this example, we'll just show a success message
        echo "Thank you, $name! Your query has been submitted successfully.";
        
        // Optional: Here you can implement saving the data to a database
        // or sending an email using PHP's mail() function
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>ContactUs</title>
</head>

<body>
    <div id="ContactUs">
        <h1>Contact Us</h1>
        <form action="contact.php" method="POST">
            <div class="form-shape">
                <label for="query">
                    Type of Query
                </label>
                <select name="myQuery" id="query">
                    <option value="sel" selected>
                        Select
                    </option>
                    <option value="ord">
                        Order related Issues
                    </option>
                    <option value="Site">
                        Site related Issues
                    </option>
                    <option value="fed">
                        Complaint related Issues
                    </option>
                    <option value="others">
                        Others
                    </option>
                </select>
            </div>
            <div class="form-shape">
                <label for="name">Name</label>
                <input type="text" name="myName" id="name"
                    placeholder="Enter your Name">
            </div>
            <div class="form-shape">
                <label for="email">Email-Id</label>
                <input type="email" name="myEmail" id="email"
                    placeholder="Enter your email">
            </div>
            <div class="form-shape">
                <label for="pho">Phone Number</label>
                <input type="text" name="myPhone" id="pho"
                    placeholder="Enter your Phone no">
            </div>
            <div id="radio">
                Are you a member of OnlineFoodShop:
                Yes <input type="radio" name="eligible" value="Yes">
                No <input type="radio" name="eligible" value="No">
            </div>
            <div class="form-shape">
                <label for="message">
                    Elaborate your query
                </label>
                <textarea name="mesg" id="message" cols="30" rows="10"></textarea>
            </div>
            <input type="submit" value="Submit">
            <input type="reset" value="Reset">
        </form>
    </div>
</body>

</html>
