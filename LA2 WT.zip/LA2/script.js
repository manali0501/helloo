document.querySelectorAll(".btn").forEach(button => {
  button.addEventListener("click", () => {
      document.getElementById("top3").scrollIntoView({
          behavior: "smooth"
      });
  });
});
